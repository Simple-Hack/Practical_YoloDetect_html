# -*- coding = utf-8 -*-
# @Time :2023/7/18 9:11
# @Author :小岳
# @Email  :401208941@qq.com
# @PROJECT_NAME :scene_info.json
# @File :  create_file.py
from utils.utils import create_file

if __name__ == '__main__':
    create_file()
